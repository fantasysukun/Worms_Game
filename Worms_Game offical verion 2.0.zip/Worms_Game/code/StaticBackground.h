#ifndef STATICBACKGROUND_H
#define STATICBACKGROUND_H

#ifdef __cplusplus
extern "C" {
#endif

	int getStaticBackground(int x, int y);
	int getDestroyableBackground(int x, int y);

#ifdef __cplusplus
}
#endif

#endif
