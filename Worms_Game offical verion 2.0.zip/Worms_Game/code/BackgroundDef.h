#ifndef BACKGROUNDDEF_H
#define BACKGROUNDDEF_H

#ifdef __cplusplus
extern "C" {
#endif

	int getTile(int x, int y);

#ifdef __cplusplus
}
#endif

#endif
